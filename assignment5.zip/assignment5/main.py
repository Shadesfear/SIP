#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 21:52:55 2020

@author: Magnus
"""

import exer1
import exer2
import exer3




def main():

    exer1.exer1()
    exer1.Exer111()
    exer1.Exer114()
    exer1.Exer13()
    exer1.exer1_4()

    exer2.exer21(0,3)
    exer2.exer22()

    exer3.exer314()
    exer3.exer316()
    exer3.exer317()
    


if __name__ == "__main__":
    main()